
import datetime

from ai_knowledge_base_universal import get_basic_answer
from system_requirements import environment_report
from neuro_growth import grow_network
from synapse_manager import update_synapses
from personality_core import generate_personality_response
from memory_manager import manage_memory
from emotion_memory import analyze_emotion
from reinforcement_tracker import track_reinforcement
from expansion import expand_logic
from network_generator import generate_new_nodes
from self_updater import SelfUpdater

def request_permission_for_code_change(reason: str) -> bool:
    """
    Prosi użytkownika o zgodę na modyfikację lub rozbudowę kodu AI.
    Args:
        reason (str): Powód lub opis proponowanej zmiany.
    Returns:
        bool: True jeśli użytkownik wyraził zgodę, False w przeciwnym razie.
    """
    print(f"[AI] Proszę o zgodę na modyfikację kodu: {reason}")
    # W wersji produkcyjnej można to zintegrować z GUI lub powiadomieniem
    resp = input("Czy wyrażasz zgodę na tę zmianę? (tak/nie): ").strip().lower()
    return resp == "tak"


class AIEngine:
    """
    Centralny silnik neuronowo-kwantowej AI.
    Integruje logikę sieci, pamięć, emocje, samorozwój i obsługę zadań.
    """
    def __init__(self):
        """
        Inicjalizuje AIEngine, resetuje ostatnie emocje i tematy.
        """
        self.last_emotion = None
        self.last_topics = []
        
        # Inicjalizuj dostęp do dynamicznych modułów
        try:
            from dynamic_loader import dynamic_module_manager
            self.dynamic_manager = dynamic_module_manager
            print("[AIEngine] System dynamicznych modułów zainicjalizowany")
        except ImportError:
            self.dynamic_manager = None
            print("[AIEngine] System dynamicznych modułów niedostępny")
            
        # Sprawdź środowisko
        from system_requirements import environment_report, get_best_dynamic_dir
        self.dynamic_dir = get_best_dynamic_dir()
        print(f"[AIEngine] Katalog dynamicznych modułów: {self.dynamic_dir}")
        
        # Próba załadowania dynamicznych modułów, jeśli istnieją
        if self.dynamic_manager:
            modules = self.dynamic_manager.list_modules()
            if modules:
                print(f"[AIEngine] Znaleziono {len(modules)} dynamicznych modułów: {', '.join(modules)}")
            else:
                print("[AIEngine] Brak dynamicznych modułów")


    def execute_dynamic_module(self, module_name: str, function_name: str, *args, **kwargs):
        """
        Wykonuje funkcję z dynamicznie załadowanego modułu, jeśli system dynamiczny jest dostępny.
        
        Args:
            module_name (str): Nazwa modułu (bez rozszerzenia .py)
            function_name (str): Nazwa funkcji do wywołania
            *args, **kwargs: Argumenty dla funkcji
            
        Returns:
            Any: Wynik funkcji lub None jeśli wystąpił błąd
        """
        if self.dynamic_manager:
            return self.dynamic_manager.call_function(module_name, function_name, *args, **kwargs)
        return None
    
    def process_input(self, user_text):
        from fact_checker import fact_check_pipeline
        """
        Przetwarza wejście użytkownika, generuje odpowiedź, aktualizuje pamięć,
        analizuje emocje, wzmacnia tematy i obsługuje komendy specjalne.
        """
        # === Odpowiedzi z bazy wiedzy ===
        basic = get_basic_answer(user_text)
        if basic and not basic.startswith("Nie znam jeszcze"):
            response = basic
        else:
            # === Generowanie odpowiedzi ===
            response = grow_network(user_text)
            response += "\n" + update_synapses(user_text)
            response += "\n" + generate_personality_response(user_text)
            
        # Sprawdź moduły dynamiczne
        if self.dynamic_manager:
            for module_name in self.dynamic_manager.list_modules():
                try:
                    dynamic_response = self.execute_dynamic_module(module_name, "process", user_text)
                    if dynamic_response:
                        response += f"\n[Moduł Dynamiczny {module_name}] {dynamic_response}"
                except Exception as e:
                    print(f"[AIEngine] Błąd modułu dynamicznego {module_name}: {e}")

        # === Pamięć i emocje ===
        manage_memory(user_text, response)
        self.last_emotion = analyze_emotion(user_text)
        track_reinforcement(user_text, response)

        # === Tematy kluczowe ===
        self.last_topics = [w.lower() for w in user_text.split() if len(w) > 3]

        # === Reakcje na komendy ===
        if user_text.lower().startswith("pobierz z internetu "):
            url = user_text[20:].strip()
            from task_executor import TaskExecutor
            fetcher = TaskExecutor()
            def on_finish(result):
                """Zapisuje wynik pobierania do pliku, pamięci i powiadamia użytkownika."""
                import datetime
                filename = f"web_result_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(result)
                try:
                    with open("ai_memory.txt", "a", encoding="utf-8") as mem:
                        mem.write(f"\n[INTERNET][{filename}]\n{result[:500]}\n")
                except Exception:
                    pass
                try:
                    from plyer import notification
                    notification.notify(title="AI: Pobieranie zakończone", message=f"Wynik zapisano w pliku: {filename}")
                except Exception:
                    pass
            try:
                from plyer import notification
                notification.notify(title="AI: Zadanie w toku", message="Pobieram dane z internetu w tle...")
            except Exception:
                pass
            fetcher.run_task_with_wakelock(fetcher.fetch_web_info_async, url, callback=on_finish)
            response += "\n[INTERNET] Zadanie pobierania uruchomione w tle. O wyniku i pliku zostaniesz powiadomiony."
        elif user_text.lower().startswith("rozbuduj kod ai") or user_text.lower().startswith("modyfikuj kod ai"):
            # Przykład: AI prosi o zgodę na rozbudowę/modyfikację
            reason = user_text[15:].strip() if len(user_text) > 15 else "Potrzeba rozbudowy funkcji."
            if request_permission_for_code_change(reason):
                response += "\n[AI] Otrzymano zgodę na rozbudowę lub modyfikację kodu. Przystępuję do działania."
                # Tu można wywołać self_updater/self_editor lub inne mechanizmy
                
                # Przykład tworzenia dynamicznego modułu
                if self.dynamic_manager:
                    module_code = f"""
# Moduł dynamiczny wygenerowany na żądanie użytkownika
# Powód: {reason}
# Data: {datetime.datetime.now().isoformat()}

def process(input_text):
    # Przykładowa funkcjonalność
    if "witaj" in input_text.lower():
        return "Witam! Ten moduł został utworzony dynamicznie."
    elif "test" in input_text.lower():
        return "Test modułu dynamicznego powódł się."
    return "Moduł dynamiczny aktywny."
"""
                    new_module_name = f"dynamic_module_{len(self.dynamic_manager.list_modules()) + 1}"
                    success = self.dynamic_manager.create_module(new_module_name, module_code)
                    if success:
                        response += f"\n[AI] Utworzono nowy moduł dynamiczny: {new_module_name}"
                    else:
                        response += "\n[AI] Nie udało się utworzyć modułu dynamicznego."
            else:
                response += "\n[AI] Zmiana kodu została anulowana przez użytkownika."
        elif user_text.lower().startswith("utwórz moduł") or user_text.lower().startswith("create module"):
            # Parsuj polecenie utworzenia modułu
            parts = user_text.split(" ", 2)
            if len(parts) >= 3:
                module_name = parts[2].strip()
                if self.dynamic_manager:
                    module_name_safe = module_name.replace("'", "").replace('"', "")
                    module_code = f"""
# Moduł dynamiczny '{module_name_safe}' wygenerowany na żądanie użytkownika
# Data: {datetime.datetime.now().isoformat()}

def process(input_text):
    # Podstawowa funkcjonalność dla modułu {module_name_safe}
    if "{module_name_safe}" in input_text.lower():
        return f"Wykryto słowo kluczowe związane z tym modułem: {module_name_safe}"
    return f"Moduł {module_name_safe} jest aktywny, ale nie wykryto słów kluczowych."

def analyze(text):
    # Funkcja analizy dla modułu {module_name_safe}
    import random
    text_words = text.lower().split()
    keyword = "{module_name_safe}"
    prefix = keyword[:4] if len(keyword) > 4 else keyword
    
    if keyword in text_words:
        return f"Analiza dla {module_name_safe}: znaleziono dokładne dopasowanie."
    
    for word in text_words:
        if len(word) > 4 and word.startswith(prefix):
            return f"Analiza dla {module_name_safe}: znaleziono {{len(text_words)}} słów z podobnym początkiem."
    
    return None
"""
                    success = self.dynamic_manager.create_module(module_name_safe, module_code)
                    if success:
                        response += f"\n[AI] Utworzono nowy moduł dynamiczny: {module_name_safe}"
                    else:
                        response += "\n[AI] Nie udało się utworzyć modułu dynamicznego."
                else:
                    response += "\n[AI] System modułów dynamicznych nie jest dostępny w tym środowisku."
            else:
                response += "\n[AI] Nieprawidłowe polecenie. Użyj 'utwórz moduł [nazwa]'."
        else:
            self._handle_commands(user_text)

            # --- FACT-CHECKING HOOK ---
            fc_result = fact_check_pipeline(user_text)
            if fc_result["warnings"]:
                response += "\n\n[UWAGA: Wykryto potencjalne ryzyko dezinformacji!]\n" + "\n".join(fc_result["warnings"])
            if fc_result["fact_api"].get("claimReview"):
                response += "\n\n[Fact-check: "
                for review in fc_result["fact_api"]["claimReview"]:
                    response += f"Źródło: {review.get('publisher', {}).get('name', '')}, Ocena: {review.get('text', '')}\n"
                response += "]"
            # --- END FACT-CHECKING HOOK ---

            # --- SYSTEM REQUIREMENTS CHECK ---
            if user_text.lower().startswith("sprawdź środowisko ai") or user_text.lower().startswith("check ai environment"):
                response += "\n\n[Raport środowiska AI:]\n" + environment_report()
            # --- END SYSTEM REQUIREMENTS CHECK ---
            
            # --- EXTENSIONS MANAGEMENT ---
            elif user_text.lower().startswith("zainstaluj rozszerzenie") or user_text.lower().startswith("install extension"):
                try:
                    from ai_extensions import install_extension, list_extensions
                    
                    parts = user_text.split(" ", 2)
                    if len(parts) >= 3:
                        extension_name = parts[2].strip()
                        extension_code = f"""
# Rozszerzenie '{extension_name}' wygenerowane przez NeuroQuantumAI
# Data: {datetime.datetime.now().isoformat()}

def process(text):
    if "{extension_name}" in text.lower():
        return f"Rozszerzenie {extension_name} wykryło słowo kluczowe!"
    return f"Rozszerzenie {extension_name} jest aktywne."

def info():
    return {{
        "name": "{extension_name}",
        "description": "Dynamiczne rozszerzenie dla NeuroQuantumAI",
        "capabilities": ["text processing", "keyword detection"]
    }}
"""
                        success = install_extension(
                            name=extension_name,
                            code=extension_code,
                            description=f"Rozszerzenie {extension_name} dla NeuroQuantumAI",
                            author="NeuroQuantumAI",
                            version="1.0"
                        )
                        
                        if success:
                            response += f"\n[AI] Zainstalowano rozszerzenie: {extension_name}"
                            extensions = list_extensions()
                            response += f"\n[AI] Dostępne rozszerzenia: {', '.join(ext['name'] for ext in extensions)}"
                        else:
                            response += f"\n[AI] Nie udało się zainstalować rozszerzenia: {extension_name}"
                    else:
                        response += "\n[AI] Nieprawidłowe polecenie. Użyj 'zainstaluj rozszerzenie [nazwa]'."
                except ImportError:
                    response += "\n[AI] System rozszerzeń nie jest dostępny w tym środowisku."
            
            elif user_text.lower().startswith("lista rozszerzeń") or user_text.lower().startswith("list extensions"):
                try:
                    from ai_extensions import list_extensions
                    extensions = list_extensions()
                    if extensions:
                        response += "\n[AI] Zainstalowane rozszerzenia:"
                        for ext in extensions:
                            methods = ", ".join(ext.get("methods", []))
                            response += f"\n- {ext['name']} (v{ext['version']}) by {ext['author']}: {ext['description']}"
                            if methods:
                                response += f"\n  Metody: {methods}"
                    else:
                        response += "\n[AI] Brak zainstalowanych rozszerzeń."
                except ImportError:
                    response += "\n[AI] System rozszerzeń nie jest dostępny w tym środowisku."
            # --- END EXTENSIONS MANAGEMENT ---
            return response

    def _handle_commands(self, user_text):
        """
        Obsługuje specjalne komendy tekstowe użytkownika (rozwój, zadania, auto-modyfikacja).
        """
        text = user_text.lower()

        if "rozwiń logikę" in text:
            expand_logic(user_text)

        if "rozbuduj sieć" in text:
            generate_new_nodes()

        if "wykonaj zadanie" in text:
            # TODO: Implement task execution logic or use TaskExecutor if needed
            pass

        if "dodaj funkcję" in text:
            snippet = (
                "# Funkcja dodana przez AI\n"
                "def auto_function():\n"
                "    print('AI wykonała polecenie.')"
            )
            updater = SelfUpdater()
            updater.append_to_file("self_editor.py", snippet)
