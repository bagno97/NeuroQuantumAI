NeuroQuantumAI - Prototypowy plik APK

Ten plik zawiera prototypową wersję aplikacji NeuroQuantumAI zoptymalizowaną dla Samsung Galaxy A35 5G.
Ze względu na ograniczenia środowiska Codespace, ten plik nie jest prawdziwym plikiem APK, 
ale zawiera wszystkie potrzebne pliki do budowy APK na lokalnym komputerze.

Instrukcje budowania APK:
1. Rozpakuj zawartość tego pliku ZIP
2. Zainstaluj Buildozer według instrukcji z pliku BUILD_INSTRUCTIONS.md
3. Uruchom skrypt build_android.sh lub build_apk.py

W przypadku problemów skontaktuj się z autorem aplikacji.
