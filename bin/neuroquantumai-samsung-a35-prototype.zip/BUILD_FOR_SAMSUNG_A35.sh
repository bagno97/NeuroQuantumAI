#!/bin/bash
# Skrypt do budowy APK dla Samsung Galaxy A35 5G

echo "Rozpoczynam budowanie APK dla Samsung Galaxy A35 5G..."
echo "Wymagania: Python 3.9+, Buildozer, Java JDK 11"

pip install buildozer==1.5.0 cython==0.29.33

# Utwórz plik buildozer.spec
cat > buildozer.spec << 'END'
[app]
title = NeuroQuantumAI
package.name = neuroquantumai
package.domain = com.example
source.dir = assets
source.include_exts = py,png,jpg,kv,atlas,json,txt
icon.filename = %(source.dir)s/icon.png
version = 0.2
requirements = python3==3.9.17,hostpython3==3.9.17,kivy==2.2.1,requests,plyer,pillow,urllib3,certifi
orientation = portrait
android.minapi = 26
android.api = 34
android.sdk = 34
android.ndk = 25b
android.archs = arm64-v8a
android.permissions = INTERNET, CAMERA, ACCESS_FINE_LOCATION, RECORD_AUDIO, READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE

[buildozer]
log_level = 2
warn_on_root = 1
color = always
verbose = 2

[app.android]
android.allow_backup = True
android.presplash_color = #ffffff
android.presplash.resize = False
android.entrypoint = org.kivy.android.PythonActivity
android.accept_sdk_license = True
android.gradle_dependencies = androidx.work:work-runtime:2.7.1
android.add_jars = androidx.work:work-runtime:2.7.1
END

echo "Uruchamiam budowanie APK..."
buildozer -v android debug

if [ -f "bin/neuroquantumai-0.2-debug.apk" ]; then
    echo "Budowanie zakończone sukcesem!"
    echo "Plik APK znajduje się w katalogu bin/"
else
    echo "Wystąpił błąd podczas budowania APK."
fi
